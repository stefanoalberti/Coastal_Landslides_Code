function [Slope,Aspect,dx,dy] = gradient_king(Elevation,R)
% -------------------------------------------------------------------------------------------------
% description: calculate the aspect, slope, dx and dy 
% input parameteres: matrix containing altitude (DEM), georeference 
% -------------------------------------------------------------------------------------------------
% input variables
% - Elevation:
% - R:
% % output variables
% - Aspect:    
% - Slope:                       
% - dx:
% - dy: 
% -------------------------------------------------------------------------------------------------



% compute size of sub-matrix
[m,n] = size(Elevation);
Slope = zeros(m,n);
Aspect = Slope;
dx = Aspect;
dy = dx;

if isfield(R,'CellExtentInWorldX')==1
x_cellsize = R.CellExtentInWorldX;
y_cellsize = R.CellExtentInWorldY;
else
x_cellsize = R.PixelExtentInWorldX;
y_cellsize = R.PixelExtentInWorldY;   
end


for j = 2:m-1
    for k = 2:n-1

        % Perform gradient computations as in ArcGIS
        dz_dx = (((Elevation(j-1,k+1))+2*(Elevation(j,k+1))+(Elevation(j+1,k+1)))-((Elevation(j-1,k-1))...
            +2*(Elevation(j,k-1))+(Elevation(j+1,k-1))))/(8*x_cellsize);
        dz_dy = (((Elevation(j+1,k-1))+2*(Elevation(j+1,k))+(Elevation(j+1,k+1)))-((Elevation(j-1,k-1))...
            +2*(Elevation(j-1,k))+(Elevation(j-1,k+1))))/(8*y_cellsize);
        
        % Compute Slope
        rise_run = sqrt(dz_dx^2+dz_dy^2);
        slope_degrees = atan(rise_run)*57.29578;
%         Slope(j,k) = round(slope_degrees);
        Slope(j,k) = slope_degrees;
        % Compute Aspect
        aspect = 57.29578*atan2(dz_dy,-dz_dx);
        %aspect = 57.29578*atan2(dz_dy,dz_dx);
        cell = aspect; 
        if aspect < 0
            cell = 90-aspect;
        elseif aspect >90
            cell = 360-aspect+90;
        else
            cell = 90-aspect;
        end
%         Aspect(j,k) = round(cell);
        Aspect(j,k) = cell;
        % Package dx and dy
        dy(j,k) = dz_dy;
        dx(j,k) = dz_dx;

    end
end
end