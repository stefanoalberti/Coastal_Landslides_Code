
clear all
%close all

%Toggles
create_surf=1;
%Create Slip Surface for given V-A relationship

%Inputs
vmag=5;
A=1*(10^vmag);
AR=1;
backslope=10; 
faceslope=90; 
cellsize=2;
beach_cells=10;

%V-A power law
L=A/(sqrt(A/AR));
W=sqrt(A/AR);
V=1*0.074*(A^1.450);
VAgoal=V/A;
Hi=VAgoal;

%Create x points for slip surface
x=linspace(0,L,200)';
x1=0; %exit point
x2=L; %entrance point
y1=0; %exit point
y2=Hi+(L-Hi/tand(faceslope))*tand(backslope); %entrance point

xcrest=Hi./tand(faceslope);
ycrest=Hi;

c=1;
figure(1)
%% Find Surface
for r=L:L/10:1000*L
    
    %solve for h and k
    
    q=sqrt((x2-x1)^2 + (y2-y1)^2);
    x3 = (x1+x2)/2;
    y3 = (y1+y2)/2;
%    xc(c,1)= x3 - sqrt(r^2-(q/2)^2)*(y1-y2)/q;
%    yc(c,1) = y3 - sqrt(r^2-(q/2)^2)*(x2-x1)/q;
%    xc(c,1)= x3 - sqrt(r^2-(q/2)^2)*(y1-y2)/q;
%    yc(c,1) = y3 - sqrt(r^2-(q/2)^2)*(x2-x1)/q;
    [C]=circ_cent([x1 y1],[x2 y2],r);
    xc(c,1)=C(1,1);
    yc(c,1)=C(1,2);
    y=-(sqrt(r^2 - (x - xc(c,1)).^2) - yc(c,1));
   
   xss=vertcat(x,xcrest,x1);
   yss=vertcat(y,ycrest,y1);
   
    cs_area(c)=polyarea(xss,yss);
    
    VA(c)=(cs_area(c)*W)/A;
    
%     plot(xss,yss); 
%     axis equal
%     pause(0.01);
    
    if VA(c)<VAgoal
    plot(xss,yss); 
    axis equal
    hold on   
        r_crit=r;
        xc_crit=xc(c);
        zc_crit=yc(c);
        
        break
    end
        
    c=c+1;
end

%Create Surface Code

% Xg=-cellsize:cellsize:1.5*round(L);
% Yg=(0:cellsize:round(W))';


Xg=-beach_cells*cellsize:cellsize:round(L,-1)+2*cellsize;
Yg=(0:cellsize:round(W,-1)+cellsize)';
[X,Y]=meshgrid(Xg,Yg);

%Booleans
beach=find(X<0);
face=find(X>=0 & X<=xcrest);
crest=find(X>=xcrest);
slipsurf=find(X>=0 & X<=L);
facecrest=find(X>=0);


%Surface DEM
Zsurf=zeros(size(X));
Zsurf(beach)=0;
Zsurf(face)=X(face).*tand(faceslope);
Zsurf(crest)=Hi+(X(crest)-min(X(crest),[],1)).*tand(backslope);

Ztemp=Zsurf(X>=0);

%Zsurf=movmean(Zsurf,5,2);

%Rupture Surface DEM
Zss=NaN(size(X));
Zss(beach)=0;
Zss(slipsurf)=-(sqrt(r^2 - (X(slipsurf) - xc_crit).^2) - zc_crit);

figure(2);
surf(X,Y,Zsurf)
axis equal
hold on
surf(X,Y,Zss)

V
sum(nansum(Zsurf-Zss)*cellsize*cellsize)



filename=strcat('AR',num2str(AR),'_A1e',num2str(vmag),'_bs',num2str(backslope),'.mat');

save(filename,'X','Y','cellsize','Zss','Zsurf')







