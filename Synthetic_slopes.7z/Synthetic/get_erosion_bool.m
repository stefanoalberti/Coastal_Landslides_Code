function [erbool_output] = get_erosion_bool(X,Y,Z,low_el,high_el)
% -------------------------------------------------------------------------------------------------
% description: Create a boolean mask for erosion zone
% input parameteres: 
% -------------------------------------------------------------------------------------------------
% input variables
% - X:                 X coordinates
% - Y:                 Y coordinates
% - Z:                 Z values of landslide (t0=Z_arizona, t1=Znew)
% - low_el:            Low elevation of tides
% - high_el:           High elevation of tides
% % output variables
% - erbool_output:     Boolean mask for erosion zone   
% -------------------------------------------------------------------------------------------------


% low_el=7;
% high_el=10;
el_incs=10;


%Initialize
Xr=X(2:end-1,2:end-1);
Yr=Y(2:end-1,2:end-1);
Zr=Z(2:end-1,2:end-1);
Zr= double(Zr); % added for Johnson case study, before it was single
erbool=zeros(size(Xr));



for el=low_el:(high_el-low_el)./el_incs:high_el
 erbool_temp=zeros(size(Xr));
 
%Find Contour for Erosion
[Mer]=contourc(Xr(1,:),Yr(:,1),Zr,[el el]);
%Mer(Mer<10000)=NaN; %Remove unnecessary data
Mer=Mer'; %Rotate

%Rasterize
% IDX = knnsearch([Xr(:),Yr(:)],Mer);

IDX = knnsearch([Xr(:),Yr(:)],Mer,'K',1);
[row, col] = ind2sub(size(Xr), IDX);
LinIdx = sub2ind(size(erbool), row, col);          
erbool_temp(LinIdx) = 1;
erbool=erbool+erbool_temp;

end

erbool(erbool>1)=1;
%imagesc(erbool)
erbool_output=zeros(size(erbool)+2);
erbool_output(2:end-1,2:end-1)=erbool;
111;
% imagesc(erbool);
% hold on
% 111;



