
clear all


%vmag=6;
%AR=0.5;
backslope=10; 
%cellsize=10; %4 for vmag=5
mw=0.0; %proportion of landslide depth that is saturated

vmagin=linspace(4,8,17); %[4 5 6 7];
vmag=[5 5.5 6 6.5 7 7.5 8];

ARin=fliplr(linspace(0.25,3,12));%fliplr([0.5 0.75 1 1.5 2]);%[0.5 0.75 1 1.25 1.5 2];
col=flipud(jet(length(ARin)));


er=0;

for mw=[0.25 0.5 0.75]
fignum=1; %dummy counter for Volume Runs
%% LOOP FOR AREA MAGNITUDE
for vmag=vmagin

%     cellsize=1*sqrt(10^(vmag-4)); %scale cellsize with area
%     dt=2*sqrt(10^(vmag-4)); %scale time increment
%     ARnum=1; %dummy counter for aspect ratios

    cellsize=5*sqrt(10^(vmag-4)); %scale cellsize with area
    dt=10*sqrt(10^(vmag-4)); %scale time increment
    ARnum=1; %dummy counter for aspect ratios

%% LOOP FOR ASPECT RATIO    
for AR=ARin

%Create File Name
name=strcat('Coarse\Amag',num2str(vmag),'_AR',num2str(AR),'_backslope',num2str(backslope),'_hw',num2str(mw),'_er',num2str(er),'.mat');    
    
%Run Analysis and Output Results
% [disp_store,phi_store,vol,count,dt,cellsize_out,Znew,Zss,Z_arizona,X,Y,erosion_rate,L]=FD_solver_dormancy(AR,vmag,backslope,cellsize,fignum,col(ARnum,:),mw,dt,er);
[disp_store,phi_store,vol,count,dt,cellsize_out,Znew,Zss,Z_arizona,X,Y,erosion_rate,L]=FD_solver_dormancy_noerosion(AR,vmag,backslope,cellsize,fignum,col(ARnum,:),mw,dt,er);

%Annotate Data
disp_store(count,1)=disp_store(count-1,1);
phi_store(count,1)=phi_store(count-1,1);
vol(count,1)=vol(count-1,1);
if ARnum==1
    tend=1.1*count*dt;
end
tnorm=(1:count)*dt; 
tnorm(end)=tend;

%Plot Data
figure(fignum)

subplot(3,1,1)
plot(tnorm,disp_store,'Color',col(ARnum,:),'LineStyle','-','LineWidth',2); 
grid on
hold on
xlim([0 tend]);

subplot(3,1,2)
plot(tnorm,phi_store,'Color',col(ARnum,:),'LineStyle','-','LineWidth',2); 
grid on
hold on
xlim([0 tend]);

% subplot(4,1,3)
% plot((1:count-1)*dt,cumsum(er_tot_store),'Color',col,'LineStyle','-');
% grid on
% hold on
% %xlim([0 365*years]);

subplot(3,1,3)
plot(tnorm,vol,'Color',col(ARnum,:),'LineStyle','-','LineWidth',2); 
grid on
hold on
xlim([0 tend]);

%Save File
save(name);


ARnum=ARnum+1;
pause(0.01)
end

fignum=fignum+1;

end

end