
clear all
%close all

%Toggles
create_surf=1;
%Create Slip Surface for given V-A relationship

%Inputs

AR=1;


vmag=4;
A=1*(10^vmag);
backslope=20; 
faceslope=90; 
cellsize=1;

%V-A power law
L=A/(sqrt(A/AR));
W=sqrt(A/AR);
V=1*0.074*(A^1.450);
VAgoal=V/A;
Hi=VAgoal;

%Create X and Y Grid
x=-5*cellsize:cellsize:L;
y=0:cellsize:W;
[X,Y]=meshgrid(x,y);




%Create Surface Elevation Grid
Z=NaN(size(X));
Z(X<=0)=0;
Z(X>0 & X<=(Hi/tand(faceslope)))=X(X>0 & X<=(Hi/tand(faceslope))).*tand(faceslope);
%Z(X>Hi/tand(faceslope))=Hi+X(X>Hi/tand(faceslope))*tand(backslope); %(original)
Z(X>Hi/tand(faceslope))=Hi+(X(X>Hi/tand(faceslope)) - min(X(X>Hi/tand(faceslope)),[],1))*tand(backslope); %(Ben)

%Z(X>Hi/tand(faceslope))=Hi+(X(X>Hi/tand(faceslope)) - max(X(X>Hi/tand(faceslope)),[],1))*tand(backslope);



%Slope Grid Slip Surface
gradZss=NaN(size(X));
gradZss(X>=0)=backslope;
gradZss(X<0)=0;
gradZss=movmean(gradZss,5,2);




%Create Slip Surface Grid
Zss_alt=cumsum(cellsize*tand(gradZss),2);

Zss=NaN(size(X));
Zss(X>=0)=X(X>=0).*tand(backslope);
Zss(X<0)=0;



% Zss=Z-Hi;
% Zss(Zss<0)=0;

surf(X,Y,Z); hold on
surf(X,Y,Zss_alt);
hold on
%surf(X,Y,Zss);

axis equal

sum(sum(Z-Zss)*cellsize*cellsize)
V

test=Z-Zss;
111;
% %Create x points for slip surface
% x=linspace(0,L,200)';
% x1=0; %exit point
% x2=L; %entrance point
% y1=0; %exit point
% y2=Hi+L*tand(backslope); %entrance point
% 
% xcrest=Hi./tand(faceslope);
% ycrest=Hi;
% 
% c=1;
% 
% %% Find Surface
% 
% for r=L:L/10:1000*L
%     
%     %solve for h and k
%     
%     q=sqrt((x2-x1)^2 + (y2-y1)^2);
%     x3 = (x1+x2)/2;
%     y3 = (y1+y2)/2;
% %    xc(c,1)= x3 - sqrt(r^2-(q/2)^2)*(y1-y2)/q;
% %    yc(c,1) = y3 - sqrt(r^2-(q/2)^2)*(x2-x1)/q;
% %    xc(c,1)= x3 - sqrt(r^2-(q/2)^2)*(y1-y2)/q;
% %    yc(c,1) = y3 - sqrt(r^2-(q/2)^2)*(x2-x1)/q;
%     [C]=circ_cent([x1 y1],[x2 y2],r);
%     xc(c,1)=C(1,1);
%     yc(c,1)=C(1,2);
%     y=-(sqrt(r^2 - (x - xc(c,1)).^2) - yc(c,1));
%    
%    xss=vertcat(x,xcrest,x1);
%    yss=vertcat(y,ycrest,y1);
%    
%     cs_area(c)=polyarea(xss,yss);
%     
%     VA(c)=(cs_area(c)*W)/A;
%     
% %     plot(xss,yss); 
% %     axis equal
% %     pause(0.01);
%     
%     if VA(c)<VAgoal
%     plot(xss,yss); 
%     axis equal
%     hold on   
%         r_crit=r;
%         xc_crit=xc(c);
%         zc_crit=yc(c);
%         
%         break
%     end
%         
%     c=c+1;
% end
% 
% %Create Surface Code
% 
% % Xg=-cellsize:cellsize:1.5*round(L);
% % Yg=(0:cellsize:round(W))';
% 
% 
% Xg=-cellsize:cellsize:round(L,-1)+2*cellsize;
% Yg=(0:cellsize:round(W,-1)+cellsize)';
% [X,Y]=meshgrid(Xg,Yg);
% 
% %Booleans
% beach=find(X<0);
% face=find(X>=0 & X<=xcrest);
% crest=find(X>=xcrest);
% slipsurf=find(X>=0 & X<=L);
% 
% %Surface DEM
% Zsurf=zeros(size(X));
% Zsurf(beach)=0;
% Zsurf(face)=X(face).*tand(faceslope);
% Zsurf(crest)=Hi+X(crest).*tand(backslope);
% 
% %Rupture Surface DEM
% Zss=NaN(size(X));
% Zss(beach)=0;
% Zss(slipsurf)=-(sqrt(r^2 - (X(slipsurf) - xc_crit).^2) - zc_crit);
% 
% figure;
% surf(X,Y,Zsurf)
% axis equal
% hold on
% surf(X,Y,Zss)
% 
% filename=strcat('AR',num2str(AR),'_A1e',num2str(vmag),'_bs',num2str(backslope),'.mat');
% 
% save(filename,'X','Y','cellsize','Zss','Zsurf')







