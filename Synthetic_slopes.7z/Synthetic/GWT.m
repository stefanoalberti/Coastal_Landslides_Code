function [vq] = GWT()
% -------------------------------------------------------------------------------------------------
% description: 
% input parameteres: 
% -------------------------------------------------------------------------------------------------
% input variables
%              
% % output variables
% 
% -------------------------------------------------------------------------------------------------

% % Rainfall data - data in SI (mm)
% addpath 'C:\Users\albertis\Desktop\Arizona\Rainfall data'
% filename  = 'PRISM_ppt_tmin_tmean_tmax_early_4km_20100701_20200701_42.6250_-124.3979.csv'
% impRFdata = readtable(filename,'Delimiter',',','ReadVariableNames',true,'HeaderLines', 10);
% n_day = (1:3654)';
% %n_day = array2table(n_day);
% %rain = [n_day impRFdata(:,2)];
% rain = table2array(impRFdata(:,2));
% rain_cum = table2array(impRFdata(:,3));
% t_avg = table2array(impRFdata(:,5));

% % Plot
% fig1 = figure ();
% bar(rain);
% xlabel 'number of day since 07/01/2010'
% ylabel 'rainfall [mm]'
% yyaxis right 
% plot (rain_cum, 'linewidth',2);
% ylabel 'cumulative rainfall [mm]'

%% GWT [data in feet]
addpath 'C:\Users\albertis\Desktop\Arizona\Shpefiles\Test Spline\'
addpath 'C:\Users\albertis\Desktop\Arizona\Shpefiles\Test Spline\Piezo mod'

% import and definition of x-y coordinate for POI and their names
filename  = 'Name_loc_piezo.csv'
POI_pos = readtable(filename,'Delimiter',',','ReadVariableNames',true);
x = table2array(POI_pos(:,3));
y = table2array(POI_pos(:,4));
POI_name = POI_pos(:,2);


%initialize results and foor loop for import data
results = [];
for points = 1:27
filename = strcat('P',num2str(points),'.csv');
impData  = table2cell(readtable(filename,'Delimiter',',','ReadVariableNames',true));
results  = [results impData(:,2)];
end 

% create grid 20 feet
%xc = min(x)-200:5:max(x)+200;
%yc = min(y)-200:4:max(y)+200;
%[xc,yc] = meshgrid(xc,yc);

%% valid for Arizona Inn
xc = 2.620285e+05+20:20:2.651685e+05;
yc = 3.426565e+05+20:20:3.452565e+05;
[xc,yc] = meshgrid(xc,yc);


%calculate grid data for every day 
for i= 1:length(results)
vc = results(i,:);
vc= cell2mat(vc');
vq = griddata(x,y,vc',xc,yc,'v4');
store_vq = vq + vq(i);



%set(0,'DefaultFigureVisible','off')
% fig=figure();
% mesh(xc,yc,vq); 
% hold on
% stem3(x,y,vc,'o','fill');

% %save figures 
% fname = 'C:\Users\albertis\Desktop\CMmatlab\Mod\fd_solver\images';
% saveas(figure(i),fullfile(fname,['Fig.' num2str(i) '.png']));

end



end
