function[R,Zsurf,Slope,Aspect,Slope_ss,Aspect_ss,dx,dy,Zss,Rss,x_cellsize,y_cellsize,nx,ny,X,Y,move_bool,beach_bool,thickness,ss_area_norm]=process_DEM(vmag,AR,backslope,faceslope,cellsize)
% -------------------------------------------------------------------------------------------------
% description: import data from geotiff files about x, y, z, georeference,
% # columns, # rows, cellsize, aspect, slope
% -------------------------------------------------------------------------------------------------
% input variables
% //
% % output variables
% - R_arizona:              georefence data of imported DEM           
% - Z_arizona:              z value (altitude) of imported DEM
% - Slope:                  slope of imported DEM (using gradient_king function)
% - Aspect:                 aspect of imported DEM (using gradient_king function)
% - Slope_ss:               slope of slip surface DEM (using gradient_king function)
% - Aspect_ss:              aspect of slip surface DEM (using gradient_king function)
% - dx:
% - dy:
% - Zss:                    z value (altitude) of slip surface DEM
% - Rss:                    georefence data of slip surface DEM
% - x_cellsize_arizona:     cell size (calculate one time because same size)
% - y_cellsize_arizona:     cell size     
% - nx_arizona:             # rows (calculate one time because same size)
% - ny_arizona:             # columns 
% - Xarizona:
% - Yarizona:
% -------------------------------------------------------------------------------------------------

%clear all

% vmag=5;
% AR=0.5;
% backslope=10; 
% faceslope=45; 
% cellsize=5;

[X,Y,Zsurf,Xss,Yss,Zss,move_bool,beach_bool,V,thickness]=slip_surf_create_synthetic_function(AR,vmag,backslope,faceslope,cellsize);

R=imref2d(size(Zsurf),[min(min(X))-cellsize/2 max(max(X))+cellsize/2],[min(min(Y))-cellsize/2 max(max(Y))+cellsize/2]);
Rss=R;

%DEM Data
x_cellsize = R.PixelExtentInWorldX;
y_cellsize = R.PixelExtentInWorldY; % 2 check
[m,n] = size(Zsurf); % m rows (x-dir), and n cols (y-dir)
nx = size(Zsurf,1); % number of rows
ny = size(Zsurf,2); % number of cols
% X = repmat((x_cellsize:x_cellsize:m*x_cellsize)',1,n);
% Y = repmat((y_cellsize:y_cellsize:n*y_cellsize),m,1);
Zsurf(Zsurf>1000 | Zsurf<-1000)=NaN;
% Compute Slope and Aspect for the base of the soil columns
[Slope,Aspect,dx,dy] = gradient_king(Zsurf,R);


%Rss=imref2d(size(Zss),[min(min(X))-cellsize/2 max(max(X))+cellsize/2],[min(min(Y))-cellsize/2 max(max(Y))+cellsize/2]);

%Slip Surface Data
x_cellsize_ss = R.PixelExtentInWorldX;
y_cellsize_ss = R.PixelExtentInWorldY; % 2 check
[m_ss,n_ss] = size(Zss); % m rows (x-dir), and n cols (y-dir)
nx_ss = size(Zss,1); % number of rows
ny_ss = size(Zss,2); % number of cols
% Xss = repmat((x_cellsize_ss:x_cellsize_ss:m_ss*x_cellsize_ss)',1,n_ss);
% Yss = repmat((y_cellsize_ss:y_cellsize_ss:n_ss*y_cellsize_ss),m_ss,1);
Zss(Zss>1000 | Zss<-1000)=NaN;
% Compute Slope and Aspect for the base of the soil columns
[Slope_ss,Aspect_ss,dx_ss,dy_ss] = gradient_king(Zss,R);

dlon=270;
dtra=360;
    dy = Slope.*cosd(dlon);% longitudinal pixel slopes
    dx = Slope.*cosd(dtra);% transverse pixel slopes

    %% Compute basic geometric properties of each column
    % Compute area of column's true base
    Atb = move_bool.*(cellsize).*(cellsize).*sqrt(1-sind(dx).^2.*sind(dy).^2)./(cosd(dx).*cosd(dy));
    ss_area_norm=sum(sum(Atb));
    meanslope=mean(mean(Slope.*move_bool));


end