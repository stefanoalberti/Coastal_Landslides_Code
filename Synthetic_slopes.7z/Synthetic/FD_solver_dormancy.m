function [disp_store,phi_store,vol,count,dt,cellsize,Znew,Zss,Z_arizona,X,Y,erosion_rate,L]=FD_solver(AR,vmag,backslope,cellsize,fignum,col,mw,dt,er)

%%
clc
%clear all;
%close all;

%% Heading 
% =================================================================================================% 
%                   MIBSE: MULTI INPUT BLOCK SLOPE and EROSION ANALYSIS                            %
% =================================================================================================% 
% AUTHORS:  Alberti S., Leshchinsky B.                                                             %
% FIRST IMPLEMENTATION DATE: 06/20/2020                                                            %
% LAST MODIFICATION DATE:   10/01/2020                                                             %
% This code has written using MATLAB® and and it is strictly of intellectual property of authors   % 
% Oregon State University                                                                          %
% =================================================================================================%

% List of variables
% -------------------------------------------------------------------------------------------------
% description: //
% -------------------------------------------------------------------------------------------------
% -------------------------------------------------------------------------------------------------  

%close all;
% clear all;
% clc;

% ver = '2.1'; 
% 
% %       
%     disp('===================================================================================================')
%     disp(['              MIBSE: MULTI INPUT BLOCK SLOPE and EROSION ANALYSIS  %',ver]                         )
%     disp('===================================================================================================')
%     disp(' Author = Leshchinsky B., Alberti S.')
%     disp(' Fist implementation date = 06/20/2020')
%     disp(' Last modification date = 10/01/2020')
%     disp(' This code has written using MATLAB® and and it is strictly of intellectual property of authors'    )
%     disp(' Oregon State University'                                                                    )    
%     disp('===================================================================================================')
% 
% clearvars ver
%% Import and Process Data
%userpath ('C:\Users\albertis\Desktop\CMmatlab\Mod\fd_solver\SA code'); % define here the directory of you files 
vidname='arizona_test';

% Set 0 if you don't need to import the variables 
% Toggles
import       =   1;
SSA          =   1;
create_video =   0; % set 1 if you wanna create video
bool         =   1; % set 0 if you don't need to create boolean mask 1 if its real case




%% Parameters
settozero=0; % if 0 nullify the parameter 

%%%%%SLOPE
%vmag=5;
%AR=0.5;
%backslope=20; 
faceslope=90; 
%cellsize=2;

%%%%%TIMESTEP
%dt=1; %days
years=1; %years
tseries=0:dt:years*365;

%%%%%MECHANICS
eta=100; % viscous parameter
sbt=1; %shear band thickness

%%%%%GROUND WATER TABLE
hw_level_low=0.1; %low proportional water level
hw_level_high=0.5; %high proportional water level

%%%%%EROSION
erosion_value=er;%0.2;
low_el  =   0; %7 Low elevation to apply to erosion [feet] 
high_el =   3*3.28; % 20% High elevation to apply to erosion [feet]
crest_buffer=3.28;



%% Import and Process Data DEM
if import==1

    %[R_arizona,Z_arizona,Slope,Aspect,Slope_ss,Aspect_ss,dx,dy,Zss,Rss,x_cellsize_arizona,y_cellsize_arizona,...
        %nx_arizona,ny_arizona,Xarizona,Yarizona,Zbool]=process_DEM_synthetic(vmag,AR,backslope,faceslope,cellsize);
        %(Ben)
    
    [R_arizona,Z_arizona,Slope,Aspect,Slope_ss,Aspect_ss,dx,dy,Zss,Rss,x_cellsize_arizona,y_cellsize_arizona,...
        nx_arizona,ny_arizona,Xarizona,Yarizona,move_bool,beach_bool,thickness,ss_area_norm,eta_ratio,L]=process_DEM_synthetic(vmag,AR,backslope,faceslope,cellsize);
    
Zbool=move_bool;    
Zbool(Zbool==2)=1;
X=Xarizona;
Y=Yarizona;
  

eta=eta*thickness;
%eta=eta*eta_ratio;   
%% Create boolean mask from Foresinic's code results  
% if bool == 1
% [X,Y,mask_bool_double, mask_bool_logical, mask_bool_double_beach, ...
%     mask_bool_logical_beach] = boolean_mask();
% end 

if years>20
rowfind=10*365/dt;   

% for rep=1:20
% results(rep*rowfind+1:(rep+1)*rowfind,:)=results(1:rowfind,:);
% end

end

end

Aspect=270*ones(size(Aspect));
Aspect_ss=270*ones(size(Aspect));
AspectSurf=270*ones(size(Aspect));

%clearvars import filename impData

dx=x_cellsize_arizona.*ones(size(dx));
dy=y_cellsize_arizona.*ones(size(dy));

%% Slope Stability Analysis to Get Direction of Sliding    
%Aspect and Slope Inputs for Slope Stability Analysis   
AspectSurf=Aspect; % Aspect from import data processing (gradient king)
asp=nanmean(nanmean(AspectSurf(Zbool==1))); %direction of sliding (???)

%Process Boolean --> clean boolean mask 
Zbool=sign(Zbool);

% Define Z and thickness of landslide inside the body
Znew=double(Z_arizona); %first definition of Z values, Znew is equal to surface of landslide from DEM
h=(Znew-Zss).*Zbool; % landslide thickness inside boundary 
h(h<=0)=0; % Correct negative thickness
h(isnan(h))=0;

%% Create boolean mask for landslide advancing
Zbool_move=Zbool;

%% Define parameters  
%GWT for initial slope stability assessment 
% pwp_grid = 0*Slope; %62.43.*(wt-(Zss.*mask_bool_logical)); %lb/ft^3 - grid of pwp values inside the landslide as altitude wospwp = gw.*(GWT - Zss)
% pwp=pwp_grid; %Slope.*0; %pwp_grid; %first assessment before moving the landslide - Pore water pressure lb/ft^3 | pwp = gw.*(GWT - Zss)
% pwp(pwp<0)=0; % Correct negative PWP

pwp=0.*h.*62.4;
% pwp=mw.*h.*62.4;
pwp(pwp<0)=0; % Correct negative PWP


%Mechanical Inputs for Slope Stability Analysis (SSA)
%Soil Parameters and Guesses
gw=62.43; % Unit weight of water/gamma water 9.8 kN/m^3
gd=0; %Unit weight of dry soil/gamma dry
gs=127.4; % Unit weight of moist soil/gamma sat 20 kN/m^3
c0=0; % Initial cohesion
phi0=0; % Arizona Inn landslide  
ky = 0.00;  % Pseudo-static coeff for EQ. in longitudinal
kx = 0;     % Pseudo-static coeff for EQ. in transverse
Ey = 0;     % Applied horizontal load in longitudinal
Ex = 0;     % Applied horizontal load in transverse


W0=h.*Zbool.*dx.*dx;%.*gs; %Soil Loading and Guesses
W0(W0<0 | isnan(W0))=0;
Slope_ss(isnan(Slope_ss))=0;
dxtemp=dx.*Zbool;
dxtemp(h==0)=0;



% Run Slope Stability Analysis with simple Janbu
if SSA==1 
[rot, phii, cf] = SimpJanbu3D(Zbool, dxtemp(:), Slope_ss(:), Aspect(:), asp(:), ...
    c0(:), phi0(:), W0(:), pwp(:), gs(:), 'phi', kx(:), ky(:), Ex(:), Ey(:),thickness);
end
clearvars SSA

% Landslide advance - initializing of the all variables involved 
disp=zeros(size(Zbool)); 
dispu=zeros(size(Zbool));
dispv=zeros(size(Zbool));
dispt=zeros(size(Zbool)); 
dztemp=zeros(size(Zbool)).*Zbool;

% increments (time step)
incs=3;
dz_step=1/incs; %(incs);

%% Erosion and landslide advancing  
% Define erosion rate e wave heights for beach boolean mask after erosion
[erbool_output] = get_erosion_bool(X,Y,Znew,low_el,high_el); % mask for erosion

% take phi from first computation of Slope Stability 
phi_actual = phii % initially the phi_actual is equal to the first phi0 calculate in the SSA 
tic
count=1;

%% Create video
if create_video==1
    vid = VideoWriter(vidname,'Motion JPEG AVI');
    vid.Quality = 95;  
    open(vid);
    figure('units','pixels','position',[0 0 1920 1080])
end










%% Start loop for erosion and landslide advancing 

vol_cond=sum(sum(h))*cellsize*cellsize;
dvol_cond=-1e-3;
while vol_cond>1 && dvol_cond<0
time=count*dt;
%for time=1:dt:365*years
 
  
vel0=0.1;
vel=vel0.*Zbool_move; %0.1 %values of velocity for each cell
%[erbool_output] = get_erosion_bool(X,Y,Znew,low_el,high_el); % mask for erosion

erbool_output=zeros(size(Z_arizona));
erbool_output(Znew<=high_el)=1;
erbool_output_pre=erbool_output;
terminal_slope=find(Znew<=high_el & Znew>=low_el);

erbool_output=double(bwmorph(erbool_output,'thicken',1));
erbool_output(erbool_output~=erbool_output_pre)=erbool_output(erbool_output~=erbool_output_pre)*crest_buffer/cellsize;      


%erbool_output=erbool_output.*beach_bool;
erbool_output(erbool_output<0)=0;


%% Update Groundwater
% hw_level=hw_level_low + (hw_level_high- hw_level_low)*(0.5 + 0.5*sind(time*360/365 -90));
% 
% hw_temp=settozero*hw_level.*(Znew-Zss); %cell thickness
% pwp_grid=62.43*hw_temp;
% pwp_grid(pwp_grid<0)=0; % (me)
% pwp_grid(isnan(pwp_grid))=0; % (me)



%% Update erosion with new Z with dz for erosion
erosion_rate=erosion_value*dt;%*((0.9.*3.280843)/116.129)*cosd(360*time/365);
erosion_rate(erosion_rate<0)=0;

%er_store(count,1)=erosion_rate;

% erbool_gradient=sum(erbool_output,2);
% erbool_output=erbool_output./erbool_gradient;
% erbool_output(isnan(erbool_output))=0;


%dz_erosion = erbool_output.*erosion_rate.*cellsize.*tand(Slope)./(cellsize*cellsize); % recalculate the z values for beach boolean mask (Ben)
dz_erosion = erosion_rate.*erbool_output;

%er_store(count,1)=sum(sum(dz_erosion))*cellsize*cellsize;

er_tot_store(count,1)=sum(sum(dz_erosion.*Zbool))*cellsize*cellsize;

Znew = Znew-dz_erosion; % Define new Z for slope considering the erosion
Znew(Znew<low_el)=low_el-0.01;

%Fix Edges
Znew(1,:)=Znew(2,:);
Znew(end,:)=Znew(end-1,:);
Znew(:,end)=Znew(:,end-1);

h=(Znew-Zss).*Zbool; % Landslide thickness
% h=(Znew-Zss).*Zbool_move; % Landslide thickness
h(h<=0)=0;
h(isnan(h))=0;

[Slope,Aspect] = gradient_king(Znew,R_arizona); % Update Alope and Aspect 
Slope(isnan(Slope))=0;
Aspect(isnan(Aspect))=270;

%% Update Slope Stability and Mechanical Inputs for Slope Stability Analysis
% pwp=pwp_grid; %Slope.*0;
% pwp(pwp<0)=0;

pwp=mw.*h.*62.4;
pwp(pwp<0)=0; % Correct negative PWP

% gw=62.43; gs=127.4; c0=0; phi0=0; %Soil Parameters and Guesses %MIND THE UNITSSSSSS
% kx=0; ky=0; Ex=0; Ey=0; W0=h.*Zbool.*dx.*dx.*gs; %Soil Loading and Guesses

%% Initial displacements
disp_init = 0; % by me 
phi0=0;
%% Run Slope Stability Analysis
W0=h.*Zbool.*dx.*dx;%.*gs; %Soil Loading and Guesses
W0(W0<0 | isnan(W0))=0;
Slope_ss(isnan(Slope_ss))=0;

dxtemp=dx.*Zbool;
dxtemp(h==0)=0;

[rot, phif, cf] = SimpJanbu3D(Zbool, dxtemp(:), Slope_ss(:), Aspect(:), asp(:), ...
c0(:), phi0(:), W0(:), pwp(:), gs(:), 'phi', kx(:), ky(:), Ex(:), Ey(:),thickness);
rot=0;

%count=count+1;
u_store(count,1)=mean(mean(pwp));
%phif=28.5;



if phif-phi_actual>1e-5;%phif>phi_actual % before if loop 
     
%Update Displacement Calculations
% disp=disp+dispt; %Cumulative Displacement Magnitude
% dispt=zeros(size(Z_arizona)); 
  %phi0=phif;  
phi0=phi_actual;
W0=h.*Zbool.*dx.*dx;%.*gs; %Soil Loading and Guesses
%W0(W0<0)=0;
W0(W0<0 | isnan(W0))=0;
Slope_ss(isnan(Slope_ss))=0;
dxtemp=dx.*Zbool;
dxtemp(h==0)=0;

%Run Slope Stability Analysis
[rot, phif, cf] = SimpJanbu3D(Zbool, dxtemp(:), Slope_ss(:), Aspect(:), asp(:), ...
    c0(:), phi0(:), W0(:), pwp(:), gs(:), 'c', kx(:), ky(:), Ex(:), Ey(:),thickness);



% sbt=1; %shear band thickness
rot=0;

velstep=(cf./eta).*sbt.*dt;

% vel=(cf./eta).*sbt.*dt.*Zbool_move;
vel=(cf./eta).*sbt.*dt.*Zbool;
u=vel.*sind(asp+rot); 
v=vel.*cosd(asp+rot);
u(isnan(u))=0;
v(isnan(v))=0;

ddisp=vel/1;
ddisp_step=velstep/1;
u=ddisp.*sind(asp+rot); 
v=ddisp.*cosd(asp+rot);
u(isnan(u))=0;
v(isnan(v))=0;




disp_step=0;
while disp_step<velstep

    for i=2:1:nx_arizona-1
    
    for j=2:1:ny_arizona-1
       
%Working CoM code
        dztemp(i,j)=h(i,j).*((v(i+1,j)-v(i-1,j))./(2*dx(i,j)))...
            +h(i,j).*((u(i,j+1)-u(i,j-1))./(2*dx(i,j)))...
            +v(i,j).*((h(i+1,j)-h(i-1,j))./(2*dx(i,j)))...
            +u(i,j).*((h(i,j+1)-h(i,j-1))./(2*dx(i,j)));
        
    end
    end
    
% dztemp(abs(dztemp)>20)=20;

%% Calculate New Surface and Geometry 
Zss(isnan(Zss))=Z_arizona(isnan(Zss));
    Znew=Znew-dztemp; %check on this, plus or minus
%     h=(Znew-Zss).*Zbool_move;
h=(Znew-Zss).*Zbool;
    h(h<=0)=0;


disp_step=disp_step+ddisp_step;


end

% Displacements 
disp=disp+vel;
dispu=dispu+u;
dispv=dispv+v;

%disp_init = 0; % by me 
dispt=disp_init+disp;

    
%  
%% Update Slope and Aspect     
[Slope,Aspect] = gradient_king(Znew,R_arizona);
Slope(isnan(Slope))=0;
Aspect(isnan(Aspect))=270;

%% Update Failure Surface if Eroded
Zss(Znew-Zss<0)=Znew(Znew-Zss<0);
[Slope_ss,Aspect_ss] = gradient_king(Zss,Rss);
Slope_ss(isnan(Slope))=0;
Aspect_ss(isnan(Aspect))=270;

%% Update Boolean
Zbool(Znew-Zss>0 | Znew<=0)=1;
cf_store(count,1)=cf;

celldisp(strcat({'Landslide Moving // Disp. is '},num2str(round(max(max(dispt)),3)),{' feet // Time is '},num2str(time),{' Days // Time Elapsed '}, num2str(toc),{' Count // Time Step '}, num2str(count)))
end 

%% Store output data
disp_store(count,1)=max(max(dispt)); %displacement time history
phi_store(count,1)=phif; %strength time history
FS_store(count,1)=tand(phif)/tand(phi_actual); %FS time history
vol(count,1)=sum(sum(h))*cellsize*cellsize;%sum(sum(W0)); %volume time history
if count==1 %volume change time hisotry
   dvol(count,1)=-1e-3; 
else
   dvol(count,1)=vol(count,1)-vol(count-1,1);
end



[midpoint,~]=size(Yarizona); 
cross_section(count,:)=Znew(midpoint,:); %cross-section time hisotry
cross_sectiont=cross_section(count,:);
cross_sectiont(cross_sectiont<=0)=NaN;
[toe,toe_idx]=nanmin(cross_sectiont); 

cx_store(:,count)=cross_sectiont;

toe_store(count,1)=Yarizona(midpoint,toe_idx); %toe location time history

if count==1 %retreat time history
    retreat(count,1)=0;
else
    retreat(count,1)=toe_store(count,1)-toe_store(count-1,1);
end

net_advance(count,1)=disp_store(count,1)-retreat(count,1); %net advance, positive is advance, negative is retreat
vol_cond=sum(sum(h))*cellsize*cellsize;
dvol_cond=dvol(count,1);

count=count+1;

% if isnan(vol_store(count-1,1)) || vol_store(count-1,1)==0 || isnan(round(max(max(dispt))))
%    break 
% end

celldisp(strcat({'Step Complete // Disp. is '},num2str(round(max(max(dispt)),3)),{' feet // Time is '},num2str(time),{' Days // Time Elapsed '}, num2str(toc),{' Count // Time Step '}, num2str(count)))

%else
    
 %   dztemp=zeros(nx_arizona,ny_arizona);
    



% for xx=1:1:1
%     dztemp=1.0*movmean(dztemp,5,1,'omitnan');
%     dztemp=1.0*movmean(dztemp,5,2,'omitnan'); 
% end

%toc

%% Video creation part
if create_video==1
hs=hillshade(Znew,Y(:,1),X(1,:),'zfactor',1);
s1=surf(X,Y,Znew,hs);
axis equal;
view(-67,21)
zlim([0 max(max(Z_arizona))]);
set(s1,'edgecolor','black','edgealpha',0.1,'linewidth',0.001);
material shiny;
colormap('gray');
frame = getframe(gcf);
writeVideo(vid,frame);
delete(s1);
end



end

if create_video==1
   close(vid); 
end

%% Import displacements data for Johnson Creek
% johnson = readtable('C:\Users\albertis\Desktop\Data4Matlab\Johnson\Johnson_displacements_min.csv','Delimiter',',','ReadVariableNames',true);
% time_johnson = table2array(johnson(:,1));
% disp_johnson = table2array(johnson(:,2));

%% Figures 
% figure(fignum)
% subplot(3,1,1)
% plot((1:count-1)*dt,disp_store,'Color',col,'LineStyle','-','LineWidth',2); 
% grid on
% hold on
% %xlim([0 365*years]);
% 
% subplot(3,1,2)
% plot((1:count-1)*dt,phi_store,'Color',col,'LineStyle','-','LineWidth',2); 
% grid on
% hold on
% %xlim([0 365*years]);
% 
% % subplot(4,1,3)
% % plot((1:count-1)*dt,cumsum(er_tot_store),'Color',col,'LineStyle','-');
% % grid on
% % hold on
% % %xlim([0 365*years]);
% 
% subplot(3,1,3)
% plot((1:count-1)*dt,vol,'Color',col,'LineStyle','-','LineWidth',2); 
% grid on
% hold on
%xlim([0 365*years]);

% figure(2)
% surf(X,Y,Znew);
% hold on
% surf(X,Y,Zss);
% axis equal
% view(0,0)
