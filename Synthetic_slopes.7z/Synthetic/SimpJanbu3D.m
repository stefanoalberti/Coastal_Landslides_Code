 %% Loop 1: Rotate failure direction
% Do so until the sum of transverse forces crosses 0
function [rot, phif, cf] = SimpJanbu3D(mask_red, csize, Slope, Aspect, asp, c0, phi0, W0, u, gs, strength, kx, ky, Ex, Ey,thickness)
% strength = 'c';
% load current_param
% phi0 = 35;
% c0 = 0;
% u = u_s;

coh_amp=max(W0(mask_red==1));

% Specify initial parameters
if strcmp(strength,'phi')==1
    st = 1;
else
    st = 2;
end
% Choose the rotation and phi increments - smaller values equal more exact
% solutions, but longer computation times
asp_inc = 1; %1
phi_inc = 1; %1
c_inc = 0.01*thickness;0.01; %was 0.01 10

W = W0.*gs;
asp_shift = 0;% Rotation of failure surface from mean aspect
%               0 means that failure direction equals mean aspect
%               Clockwise is positive
switchA = 0;% 0 means sum of transverse forces has not been positive
switchB = 0;% 0 means sum of transverse forces has not been negative
% Only once both positive and negative sums have been achieved does
% switchA*switchB = 0, and the looping stops.

iter2 = 0;

inc = 1;% FILL IN
ias = 1;% FILL IN
asp0 = asp;% Record initial aspect so that asp may be manipulated
while switchA*switchB == 0

    % Apply aspect shift to aspect (0 for attempt 1)
    asp = asp0+asp_shift;
    % Project slope vectors into longitudinal (failure
    % direction) and transverse directions - simple dot product
    dlon = Aspect-asp;% Difference between each pixel's aspect
                      % and the longitudinal direction
    dtra = (Aspect+90)-asp;% Difference between each pixel's
                      % aspect and the transverse direction
    dy = Slope.*cosd(dlon);% longitudinal pixel slopes
    dx = Slope.*cosd(dtra);% transverse pixel slopes

    %% Compute basic geometric properties of each column
    % Compute area of column's true base
    Atb = (csize).*(csize).*sqrt(1-sind(dx).^2.*sind(dy).^2)./(cosd(dx).*cosd(dy));

    
    % Compute local dip of sliding surface
    gz = sqrt(1./(tand(dy).^2+tand(dx).^2+1));

    %% Loop 2: Increase phi until FS passes 1.0
    phi = phi0;        % Start with phi = 1
    c = c0;%*ones(size(W0));
    FSy = 1;
    FRy = 0;
    FDy = 1;
    iter = 0;
    
    %c(W0==0)=0;
    
    while FRy<FDy
        if st == 1
            phi = phi+phi_inc;
        else
            c = c+c_inc;
        end
        iter = iter+1;

        
        
        
        %% Compute LONGITUDINAL stability
        % Compute normal force at base of column (Assume FS = 1)
        md = gz.*(1+(sind(dy).*tand(phi))./(FSy.*gz));
        N = (W-c.*Atb.*sind(dy)./FSy+u.*Atb.*tand(phi).*sind(dy)./FSy)./md;

        % Compute FS
        term1 = c.*Atb.*gz+(N-u.*Atb).*tand(phi).*cosd(dy);
        term2 = N.*gz.*tand(dy);
        term3 = ky.*W+Ey;
        sum_t1 = sum(term1); sum_t2 = sum(term2); sum_t3 = sum(term3);

        FRy = sum_t1;
        FDy = sum_t2+sum_t3;

        FSY(iter) = sum_t1/(sum_t2+sum_t3);
        ITER(iter) = iter;
        FRY(iter) = FRy;
        FDY(iter) = FDy;
        
        if st == 1
            PHI(iter) = phi;
        else
            C(iter) = c;
        end

        % Identify correct factor of safety
        FSx1 = 100; %100
        mdx = gz.*(1+(sind(dx).*tand(phi))./(FSx1.*gz));
        Nx = (W-c.*Atb.*sind(dx)./FSx1+u.*Atb.*tand(phi).*sind(dx)./FSx1)./mdx;
        term1x = c.*Atb.*gz+(Nx-u.*Atb).*tand(phi).*cosd(dx);
        term2x = N.*gz.*tand(dx);
        term3x = kx.*W+Ex;
        sum_t2x = sum(term2x); sum_t3x = sum(term3x);
        FSx2 = sum(term1x)/(sum_t2x+sum_t3x);

        % Run equation again to obtain driving forces at correct FS
        mdx = gz.*(1+(sind(dx).*tand(phi))./(FSx2.*gz));
        Nx = (W-c.*Atb.*sind(dx)./FSx2+u.*Atb.*tand(phi).*sind(dx)./FSx2)./mdx;
        term1x = c.*Atb.*gz+(Nx-u.*Atb).*tand(phi).*cosd(dx);
        term2x = N.*gz.*tand(dx);
        term3x = kx.*W+Ex;
        sum_t2x = sum(term2x); sum_t3x = sum(term3x);
        FRx = sum(term1x);
        FDx = sum_t2x+sum_t3x;
    end
    if iter > 1
        xi = [FSY(iter-1) FSY(iter)];
        if st == 1
            vi = [PHI(iter-1) PHI(iter)];
            phif = interp1(xi,vi,1);
            cf = c;
        else
            vi = [C(iter-1) C(iter)];
            cf = interp1(xi,vi,1);
            phif = phi;
        end
        xi = []; vi = [];
    else
        if st == 1
            phif = PHI(iter)-phi_inc;
            cf = c;
        else
            cf = C(iter)-c_inc;
            phif = phi;
        end
    end

    iter2 = iter2+1;
    FRX(iter2) = FRx;
    FDX(iter2) = FDx;
    FS1(iter2) = FSx1;
    FS2(iter2) = FSx2;
    ITER2(iter2) = iter2;
    ROT(iter2) = asp_shift;

    
    if FDx>0
        switchA = 1;
    else
        switchB = 1;
    end
    if iter2 == 2
        if abs(FDX(1))<abs(FDX(2))
            ias = -1;
        end
    end
    asp_shift = asp_shift+ias*asp_inc;

    %Ben added
    if iter2>1000
        rot=0;
        phif=phi0; 
        cf=0;
        return
    end
end
if iter2 > 1
    xi = [FDX(iter2-1) FDX(iter2)];
    vi = [ROT(iter2-1) ROT(iter2)];
    rot = interp1(xi,vi,0);
    xi = []; vi = [];
else
    rot = ROT(iter2);
end

% asp_shift = asp_shift-ias*asp_inc;
% table(phif,cf,rot)