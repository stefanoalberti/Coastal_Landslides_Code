clear all
%close all

%Landslide Properties
backslope=10; 
Veq=1000; %equivalent volume of erosion, m3/m, T*er_rate
erosion_value=0.2*3*3.28; %erosion rate, ft3/ft
teq=(Veq*35.3147/3.28)/erosion_value; %equivalent time
erosion_value_m3=teq*3.28*erosion_value/(3.28*3.28*3.28);


%Loop Values
vmagin_extract=linspace(4,8,17); %[4 5 6 7];
vmag=[5 6 7 8];%[5 5.5 6 6.5 7 7.5 8];
ARbatch=[0.5 1 2];%[0.5 1 1.5 2];%fliplr(linspace(0.25,3,12));%fliplr([0.5 0.75 1 1.5 2]);%[0.5 0.75 1 1.25 1.5 2];

colorplot=flipud(winter(3)); %color scheme

for mw=[0.75]% [0 0.25 0.5 0.75] %proportion of landslide depth that is saturated
fignum=1; %dummy counter 

%LOOP FOR ASPECT RATIO
j=1;

for AR=ARbatch
    
%LOOP FOR VOLUME       
i=1;

for vmag=vmagin_extract    
%name=strcat('Amag',num2str(vmag),'_AR',num2str(AR),'_backslope',num2str(backslope),'_hw',num2str(mw),'.mat');%extract refined data
name=strcat('Coarse\Amag',num2str(vmag),'_AR',num2str(AR),'_backslope',num2str(backslope),'_hw',num2str(mw),'.mat');%extract coarse data 
load(name);

%Relevant Metadata
ARi(i)=AR; %store aspect ratio
V(i)=0.074*(((10^vmag))^1.450)/(3.28*3.28*3.28); %convert landslide volume to m3

%Normalized Displacement Values
maxdisp(i)=max(disp_store)/L;
dispt(i)=(interp1((0:1:count-1)*dt,disp_store,teq))/L;

%Gather no erosion cases
name=strcat('Coarse\Amag',num2str(vmag),'_AR',num2str(AR),'_backslope',num2str(backslope),'_hw',num2str(mw),'_er0','.mat'); 
load(name);

%Normalized Displacement Values
dispt0(i)=(interp1((0:1:count-1)*dt,disp_store,teq))/L;
dispt0(isnan(dispt0))=0;

%Proportion of movement due to erosion
prop(i)=dispt(i)/dispt0(i);

i=i+1;
    
end

%Smoothed Displacement Data
vinterp=linspace(4,8,100);
vinterpm3=0.074.*(((10.^vinterp)).^1.450)./(3.28*3.28*3.28);
dispt_smooth=interp1(vmagin_extract,dispt,vinterp);
remnan=(dispt_smooth./dispt_smooth);
dispt_smooth=smooth(dispt_smooth,20);
dispt_smooth=dispt_smooth'.*remnan;

%Smoothed Displacement Data, no Erosion
vinterp0=linspace(4,8,100);
vinterp0m3=0.074.*(((10.^vinterp0)).^1.450)./(3.28*3.28*3.28);
dispt_smooth0=interp1(vmagin_extract,dispt0,vinterp0);
remnan0=(dispt_smooth0./dispt_smooth0);
dispt_smooth0=smooth(dispt_smooth0,20);
dispt_smooth0=dispt_smooth0'.*remnan0;

prop_smooth=dispt_smooth./dispt_smooth0;

%dispt=smooth(dispt
% 
figure(1)
plot(vinterp0m3,prop_smooth,'Color',colorplot(j,:),'LineStyle','-','LineWidth',2); hold on
set(gca,'Xscale','log')
grid on
xlabel('Volume [m^{3}]')
ylabel('\delta/\delta_{er=0}')
xlim([1e3 1e8])


figure(2)
%plot(V,dispt,'Color',colorplot(j,:),'LineStyle','-'); hold on
plot(vinterpm3,dispt_smooth,'Color',colorplot(j,:),'LineStyle','-','LineWidth',2); hold on
%plot(V,dispt0,'Color',colorplot(j,:),'LineStyle','--'); hold on
xlim([1e3 1e8])
%set(gca,'Yscale','log')
set(gca,'Xscale','log')
grid on
xlabel('Volume [m^{3}]')
ylabel('\delta/L')

j=j+1;
end

end