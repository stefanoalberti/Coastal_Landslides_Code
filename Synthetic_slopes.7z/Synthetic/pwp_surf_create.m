
clear all
close all
% add path
addpath 'C:\Users\albertis\Desktop\Synthetic Slopes\AR=0.25' %Syntethic 
addpath 'C:\Users\albertis\Desktop\Synthetic Slopes\AR=0.25\POI_GWT_AR_025' %Syntethic

% import and definition of x-y coordinate for POI and their names
filename  = 'Loc_GWT_POI_AR025.csv'; %filename  = 'POI_GWT_Carmel.csv'; filename  = 'POI_GWT_Johnson.csv'; ='Name_loc_piezo.csv' (Arizona)
POI_pos = readtable(filename,'Delimiter',',','ReadVariableNames',true);
x = table2array(POI_pos(:,3)); %x coordinate of points for GWT interpolation
y = table2array(POI_pos(:,4)); %y coordinate of points for GWT interpolation
POI_name = POI_pos(:,2);

% Initialize results and foor loop for import data
results = [];

% Define position of points for gridding GWT

for points = 1:12 %23(Johnson) %21(Carmel) %27(Arizona) %12 (Synthetic)
filename = strcat('P',num2str(points),'.csv');
impData  = table2cell(readtable(filename,'Delimiter',',','ReadVariableNames',true));
gwtemp=cell2mat(impData(:,2));
results(:,points)=interp1(0:1:length(gwtemp)-1,gwtemp,tseries);
%results(:,p)=cell2mat(impData(:,2));
%results  = [results impData(:,2)];
end 

%% Define parameters  
%GWT for initial slope stability assessment 
vc = results(1,:); % line with value of each point with GWT value 
% vc= cell2mat(vc'); % column with value of each point with GWT value 
vc= (vc'); % column with value of each point with GWT value 
vq = griddata(x,y,vc',X,Y,'v4'); % grid interpolation with daily data and coordinate defined previously 
wt = vq.*mask_bool_logical; % mask for GWT inside the landslide 

%% remain on the main code
pwp_grid = 62.43.*(wt-(Zss.*mask_bool_logical)); %lb/ft^3 - grid of pwp values inside the landslide as altitude
%Mechanical Inputs for Slope Stability Analysis (SSA)
%Soil Parameters and Guesses
pwp=pwp_grid;
%----------------------------------------------------------------------------------------------------%


%Toggles
create_surf=1;
%Create Slip Surface for given V-A relationship

%Inputs
vmag=3;
A=1*(10^vmag);
AR=0.25;
backslope=20; 
faceslope=45; 
cellsize=2;

%V-A power law
L=A/(sqrt(A/AR));
W=sqrt(A/AR);
V=1*0.074*(A^1.450);
VAgoal=V/A;
Hi=VAgoal;

%Create x points for slip surface
x=linspace(0,L,200)';
x1=0; %exit point
x2=L; %entrance point
y1=0; %exit point
y2=Hi+L*tand(backslope); %entrance point

xcrest=Hi./tand(faceslope);
ycrest=Hi;

c=1;

%% Find Surface
for r=L:L/10:1000*L
    
    %solve for h and k
    
    q=sqrt((x2-x1)^2 + (y2-y1)^2);
    x3 = (x1+x2)/2;
    y3 = (y1+y2)/2;
%    xc(c,1)= x3 - sqrt(r^2-(q/2)^2)*(y1-y2)/q;
%    yc(c,1) = y3 - sqrt(r^2-(q/2)^2)*(x2-x1)/q;
%    xc(c,1)= x3 - sqrt(r^2-(q/2)^2)*(y1-y2)/q;
%    yc(c,1) = y3 - sqrt(r^2-(q/2)^2)*(x2-x1)/q;
    [C]=circ_cent([x1 y1],[x2 y2],r);
    xc(c,1)=C(1,1);
    yc(c,1)=C(1,2);
    y=-(sqrt(r^2 - (x - xc(c,1)).^2) - yc(c,1));
   
   xss=vertcat(x,xcrest,x1);
   yss=vertcat(y,ycrest,y1);
   
    cs_area(c)=polyarea(xss,yss);
    
    VA(c)=(cs_area(c)*W)/A;
    
%     plot(xss,yss); 
%     axis equal
%     pause(0.01);
    
    if VA(c)<VAgoal
    plot(xss,yss); 
    axis equal
    hold on   
        r_crit=r;
        xc_crit=xc(c);
        zc_crit=yc(c);
        
        break
    end
        
    c=c+1;
end

%Create Surface Code

% Xg=-cellsize:cellsize:1.5*round(L);
% Yg=(0:cellsize:round(W))';


Xg=-cellsize:cellsize:round(L,-1)+2*cellsize;
Yg=(0:cellsize:round(W,-1)+cellsize)';
[X,Y]=meshgrid(Xg,Yg);

%Booleans
beach=find(X<0);
face=find(X>=0 & X<=xcrest);
crest=find(X>=xcrest);
slipsurf=find(X>=0 & X<=L);

%Surface DEM
Zsurf=zeros(size(X));
Zsurf(beach)=0;
Zsurf(face)=X(face).*tand(faceslope);
Zsurf(crest)=Hi+X(crest).*tand(backslope);

%Rupture Surface DEM
Zss=NaN(size(X));
Zss(beach)=0;
Zss(slipsurf)=-(sqrt(r^2 - (X(slipsurf) - xc_crit).^2) - zc_crit);

figure;
surf(X,Y,Zsurf)
axis equal
hold on
surf(X,Y,Zss)

filename=strcat('AR',num2str(AR),'_A1e',num2str(vmag),'_bs',num2str(backslope),'.mat');

save(filename,'X','Y','cellsize','Zss','Zsurf')







