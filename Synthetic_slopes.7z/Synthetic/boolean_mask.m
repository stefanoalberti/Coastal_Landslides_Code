function [X,Y,mask_bool_double, mask_bool_logical, mask_bool_double_beach, mask_bool_logical_beach] = boolean_mask()
% [DEM_area, rupt_surf, land_extension, DEM_area_imp, rupt_surf_imp, R, x, y, X, Y, roi, rx, ry, C, D, mask_bool_double, mask_bool_logical, roi_beach,mask_bool_double_beach, mask_bool_logical_beach,rx_beach,ry_beach]
% -------------------------------------------------------------------------------------------------
% description: create the boolean mask of landslide and beach
% input parameteres: 
% -------------------------------------------------------------------------------------------------
% input variables
% //
% % output variables
% - X:                          X coordinates
% - Y:                          Y coordinates
% - mask_bool_double:           mask of landslide (deposit) double format
% - mask_bool_logical:          mask of landslide (deposit) logical format
% - mask_bool_double_beach:     mask of beach (deposit) double format
% - mask_bool_logical_beach:    mask of beach (deposit) logical format
% -------------------------------------------------------------------------------------------------

clc;
clear all;
%----------------------------------------------------------------------------------------------------%
% IMPORT DATA AND CREATE MASK                                                                        %
%----------------------------------------------------------------------------------------------------%
% define directories --> change before the use
userpath ('C:\Users\albertis\Desktop\Synthetic Slopes\'); % define here the directory of you files 

%DEM area
DEM_area = 'C:\Users\albertis\Desktop\Synthetic Slopes\AR=1.00(Ben)\ASCII_synthetic_slope_AR_100.tif';
    %C:\Users\albertis\Desktop\Synthetic Slopes\Raster\test_synt_slope.tif % Synthetic
    %C:\Users\albertis\Desktop\Data4Matlab\Input Files\Johnson Creek\be44124f4_cut_20feet.tif % Johnson
    %C:\Users\albertis\Desktop\Data4Matlab\Input Files\Arizona\dem_20feet_arizona_UTM.tif % Arizona
% Slip surface from Micheal Bunn's code
rupt_surf = 'C:\Users\albertis\Desktop\Synthetic Slopes\AR=1.00(Ben)\ASCII_synthetic_slip_surface_AR_100.tif';
    %C:\Users\albertis\Desktop\Synthetic Slopes\AR=0.25\ASCII_synthetic_slip_surface_AR_025.tif % Synthetic
    %C:\Users\albertis\Desktop\Data4Matlab\Input Files\Arizona\slip_surf.tif' % Arizona 
    %C:\Users\albertis\Desktop\Data4Matlab\Johnson\johnson_RP_20200707_simplified\Rupture_Surfaces\slip_surf.tif' % Johnson 
% Shapefile landslide extension
land_extension = 'C:\Users\albertis\Desktop\Synthetic Slopes\AR=1.00(Ben)\landslide_100_test.shp';
    %C:\Users\albertis\Desktop\Synthetic Slopes\AR=0.25\landslide_025.shp % Synthetic
    %C:\Users\albertis\Desktop\Data4Matlab\Input Files\Arizona\deposit.shp' % Arizona
    %C:\Users\albertis\Desktop\Data4Matlab\Johnson\deposit_SA_single_slido_simp.shp' % Johnson
% Shapefile beach extension
beach = 'C:\Users\albertis\Desktop\Synthetic Slopes\AR=1.00(Ben)\beach_100_test.shp'; % normal beach
    %C:\Users\albertis\Desktop\Synthetic Slopes\AR=0.25\beach_025.shp %Synthetic
    %C:\Users\albertis\Desktop\Data4Matlab\Input Files\Arizona\beach_gen.shp' % Arizona
    %C:\Users\albertis\Desktop\Data4Matlab\Johnson\johnson_RP_20200707_simplified\beach_gen.shp' % Johnson
    
%------------------------------%
% Import DEMs  
DEM_area_imp =  readgeoraster (DEM_area); 
rupt_surf_imp = readgeoraster (rupt_surf); 
% Get image info
R = geotiffinfo(DEM_area); 
% Get x,y locations of pixels: 
[x,y] = pixcenters(R); 
% Convert x,y arrays to grid - region of interest : 
[X,Y] = meshgrid(x,y);
roi = shaperead(land_extension);
roi_beach = shaperead(beach);
% Remove trailing nan from shapefile
rx = roi.X(1:end-1);
ry = roi.Y(1:end-1);
rx_beach = roi_beach.X(1:end-1);
ry_beach = roi_beach.Y(1:end-1);
mask_bool_logical = inpolygon(X,Y,rx,ry); % generate boolean values to indicate in/outside landslide
mask_bool_double = double(mask_bool_logical); % grid as double values of in/outside landslide
mask_bool_logical_beach = inpolygon(X,Y,rx_beach,ry_beach); % generate boolean values to indicate in/outside beach
mask_bool_double_beach = double(mask_bool_logical_beach); % grid as double values of in/outside beach
% Create grid
C=DEM_area_imp.*(mask_bool_logical); %grid with altitude value just inside the landslide
D=rupt_surf_imp.*(mask_bool_logical); %grid with altitude value of slip surface just inside the landslide
% Write the GeoTiffs of Slip Surface
geotiffwrite('Slip_surface.tif', D, R.SpatialRef, 'CoordRefSysCode', 26912);
geotiffwrite('Slip_surface_bool.tif', mask_bool_double, R.SpatialRef, 'CoordRefSysCode', 26912);

%S(1) = load('gong');
%sound(S(1).y,S(1).Fs);
end
