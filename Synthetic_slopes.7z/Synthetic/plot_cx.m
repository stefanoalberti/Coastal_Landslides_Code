
figure;

cx_store(isnan(cx_store))=0;
for i=1:1:count-1
    
   h=plot(cx_store(:,i),'k');
   hold on
   ylim([0 max(max(cx_store))])
    pause(0.01)
    if i==count-1
    
    else
    delete(h)
    end
end