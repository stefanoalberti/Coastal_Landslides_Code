



for timeplot=1:1:count-1
    
   p1=plot(Yarizona(1,:),cross_section(timeplot,:),'k');
   %axis equal
   grid on
   xlim([min(Yarizona(1,:)) max(Yarizona(1,:))])
   ylim([min(Z_arizona(1,:)) max(Z_arizona(1,:))])
   pause(0.01);
   delete(p1)
    
    
    
end