
function [X,Y,Zsurf,Xss,Yss,Zss,move_bool,beach_bool,V,Hi]=slip_surf_create_synthetic_function(AR,vmag,backslope,faceslope,cellsize)


%clear all
%close all

%Toggles
create_surf=1;
%Create Slip Surface for given V-A relationship

%Inputs
%vmag=5;
A=1*(10^vmag);
%AR=0.5;
%backslope=10; 
%faceslope=45; 
%cellsize=5;
beach_length=100;
beach_cells=round(beach_length/cellsize);
cell_smooth=round(30/cellsize);


%V-A power law
L=A/(sqrt(A/AR));
W=sqrt(A/AR);
V=1*0.074*(A^1.450);
VAgoal=V/A;
Hi=VAgoal;

%Create x points for slip surface
x=linspace(0,L,200)';
x1=0; %exit point
x2=L; %entrance point
y1=0; %exit point
y2=Hi+(L-Hi/tand(faceslope))*tand(backslope); %entrance point

xcrest=Hi./tand(faceslope);
ycrest=Hi;







c=1;
%figure(1)
%% Find Surface
for r=L:L/10:1000*L
    
    %solve for h and k
    
    q=sqrt((x2-x1)^2 + (y2-y1)^2);
    x3 = (x1+x2)/2;
    y3 = (y1+y2)/2;
%    xc(c,1)= x3 - sqrt(r^2-(q/2)^2)*(y1-y2)/q;
%    yc(c,1) = y3 - sqrt(r^2-(q/2)^2)*(x2-x1)/q;
%    xc(c,1)= x3 - sqrt(r^2-(q/2)^2)*(y1-y2)/q;
%    yc(c,1) = y3 - sqrt(r^2-(q/2)^2)*(x2-x1)/q;
    [C]=circ_cent([x1 y1],[x2 y2],r);
    xc(c,1)=C(1,1);
    yc(c,1)=C(1,2);
    y=-(sqrt(r^2 - (x - xc(c,1)).^2) - yc(c,1));
   
   xss=vertcat(x,xcrest,x1);
   yss=vertcat(y,ycrest,y1);
   
    cs_area(c)=polyarea(xss,yss);
    
    VA(c)=(cs_area(c)*W)/A;
    
%     plot(xss,yss); 
%     axis equal
%     pause(0.01);
    
    if VA(c)<VAgoal
%     plot(xss,yss); 
%     axis equal
%     hold on   
        r_crit=r;
        xc_crit=xc(c);
        zc_crit=yc(c);
        
        break
    end
        
    c=c+1;
end


%Create Surface Code
Xg=-beach_cells*cellsize:cellsize:round(L,-1)+10*cellsize;
% Yg=(0:cellsize:round(W,-1)+cellsize)';
Yg=(-cellsize-(0.25)*round(W,-1):cellsize:1.25*round(W,-1)+cellsize)';
[X,Y]=meshgrid(Xg,Yg); %surface topography

%Slip Surface
Xss=X;
Yss=Y;
Zbool_find=find(Xg>=-beach_cells*cellsize & Xg<=round(L,-1) & Yg>=0 & Yg<=round(W,-1));

%Booleans
beach=find(X<0);
face=find(X>=0 & X<=xcrest);
crest=find(X>=xcrest);
slipsurf=find(Xss>=0 & Xss<=L);
facecrest=find(X>=0);

%Surface DEM
Zsurf=zeros(size(X));
Zsurf(beach)=0;
Zsurf(face)=X(face).*tand(faceslope);
Zsurf(crest)=Hi+(X(crest)-min(X(crest),[],1)).*tand(backslope);
Ztemp=Zsurf(X>=0);

%Zsurf=movmean(Zsurf,cell_smooth,2);

%Rupture Surface DEM
Zss=NaN(size(Xss));
Zss(beach)=0;
% Zss(slipsurf)=-(sqrt(r^2 - (Xss(slipsurf) - xc_crit).^2) - zc_crit);
Zss(slipsurf)=Zsurf(slipsurf)-Hi;


%Smooth Rupture Surface
Zbool=zeros(size(Zsurf));
Zbool(Zbool_find)=1;
Zss(Zbool==0)=Zsurf(Zbool==0);
%Zss=movmean(Zss,2*cell_smooth,1);
Zss=movmean(Zss,2,1);
Zss(Zsurf-Zss<1e-5)=Zsurf(Zsurf-Zss<1e-5);


%Create Booleans
beach_bool=zeros(size(X));
%beach_bool(Zsurf<=0)=1; (Ben)
beach_bool(Zsurf<=14)=1;
move_bool=zeros(size(X));
move_bool(Zsurf-Zss>0)=1;
move_bool=move_bool+beach_bool;


h=Zsurf-Zss;


% figure(2);
% surf(X,Y,Zsurf,move_bool)
% axis equal
% hold on
% surf(Xss,Yss,Zss,move_bool)

% V
% sum(nansum(Zsurf-Zss)*cellsize*cellsize)
% V/sum(nansum(Zsurf-Zss)*cellsize*cellsize)


% filename=strcat('AR',num2str(AR),'_A1e',num2str(vmag),'_bs',num2str(backslope),'.mat');
% 
% save(filename,'X','Y','cellsize','Zss','Zsurf')







